void printWifiDetail();
bool getWifiData();
int *covertIpStringToInt(String ipAddress);
bool setupWifi();
bool setupSmartConfig();
String fixValue(int input);
void clearLastedEEPROM();
String readEEPROM(char add);
void writeEEPROM(char add,String data);
