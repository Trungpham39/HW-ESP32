#include <SPI.h>
#include <WiFi.h>
#include <WebServer.h>

WiFiClient client;
static bool serverState = false;
static WiFiServer server(80); 
static IPAddress ip;
static int serverPort = 0;

void setStaticIP( IPAddress ipServer, IPAddress gateway, IPAddress subnet){
    WiFi.config(ipServer, gateway, subnet);
}

void initialServer(){
    server.begin();
    client = server.available();
    Serial.println("Initial Server");
    Serial.print("Server avaiable: ");
        Serial.println(client);
        serverState = true;
}

bool isServerOn(){
    return serverState;
}

void messageHandle(){
    client = server.available();
    if(client){
        if(client.connected()){
            String message = client.readStringUntil('\r');
            Serial.println("Client connected!");
            Serial.print("Message length: "); Serial.println(message.length());
            int length = message.length();
            if(length == 6){
                Serial.println("Got a message from android!");
            }
            else if(length == 7){
                Serial.println("Got a message from slave!");
            }
            client.flush();
        }
        else{
            Serial.println("Client disconnected!");
            client.stop();
        }
        
    }

}  


void clientConnectToServer(int port, IPAddress ipServer){
    Serial.print("Connect to server: ");
    Serial.println(ipServer);
    ip = ipServer; 
    serverPort = port;

}

//Message must follow this structure: IP_PORT_VALUE_SENSOR
//Message length: XXX.XXX.XXX.XX.X.XX
//Example: 192.168.123.132.P0.1.32
void clientSetMessage(String message){
    Serial.print("Sending message: ");
    Serial.println(message);
    client.connect(ip, serverPort);
    client.println(message);
    client.flush();
}