void setStaticIP( IPAddress ipServer, IPAddress gateway, IPAddress subnet);
void initialServer();
bool isServerOn();
void messageHandle();
void clientConnectToServer(int port, IPAddress ipServer);
void clientSetMessage(String message);