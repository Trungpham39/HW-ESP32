double getCurrent(int adcvalue);
double getVoltage(int adcvalue);