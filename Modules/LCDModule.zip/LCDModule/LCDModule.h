void lcdPrint(int x, int y, String z );
void initialLcd();
void offLcd(int GND);